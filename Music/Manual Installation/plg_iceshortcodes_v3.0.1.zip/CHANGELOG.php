<?php
/**
 * IceShortCodes Extension for Joomla 3 By IceTheme
 * 
 * 
 * @copyright	Copyright (C) 2008 - 2013 IceTheme.com. All rights reserved.
 * @license		GNU General Public License version 2
 * 
 * @Website 	http://www.icetheme.com/extensions/iceshortocdes
 * @Support 	http://www.icetheme.com/forum/categories/iceshortcodes/listings
 *
 */
 
/* no direct access*/
defined('_JEXEC') or die;

?>

?>

Copyright and disclaimer
---------------------------
This application is opensource software released under the GPL.  Please
see source code and the LICENSE file.


Changelog
------------


-------------------- 3.0.1 Stable Release [17-OCTOBER-2013] ----------------
- #38 - Fixed - bug in line 252 with box shorcodes
	  - Fixed - adjusted buttons shortcode styling and some wrong format



-------------------- 3.0.0 Stable Release [25-APRIL-2013] ------------------

