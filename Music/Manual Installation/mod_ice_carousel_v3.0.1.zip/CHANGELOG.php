<?php
/**
 * IceAccordion Extension for Joomla 3.0 By IceTheme
 * 
 * 
 * @copyright	Copyright (C) 2008 - 2012 IceTheme.com. All rights reserved.
 * @license		GNU General Public License version 2
 * 
 * @Website 	http://www.icetheme.com/Joomla-Extensions/iceaccordion.html
 *
 */
 

/* no direct access*/
defined('_JEXEC') or die;
/* Include the syndicate functions only once*/

?>

Copyright and disclaimer
---------------------------
This application is opensource software released under the GPL.  Please
see source code and the LICENSE file.


Changelog
------------

-------------------- 3.0.1 Stable Release [16-JANUARY-2014] ------------------
- Added "moderna" theme


-------------------- 3.0.0 Stable Release [10-NOVEMBER-2012] ------------------

